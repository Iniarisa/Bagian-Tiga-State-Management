import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_bloc/flutter_bloc.dart';

// Event untuk mengubah negara ASEAN yang dipilih
class CountryChanged extends Cubit<String> {
  CountryChanged() : super('Indonesia'); // Negara ASEAN default

  // Fungsi untuk mengubah negara yang dipilih
  void changeCountry(String country) =>
      emit(country); // Emit event perubahan negara
}

// State untuk mengelola data universitas
class UniversityState {
  final List universities;
  final String selectedCountry;

  UniversityState(this.universities, this.selectedCountry);
}

// Cubit untuk mengelola data universitas dan negara ASEAN
class UniversityCubit extends Cubit<UniversityState> {
  UniversityCubit() : super(UniversityState([], 'Indonesia')); // State awal

  // Fungsi untuk mengambil data universitas berdasarkan negara yang dipilih
  void fetchUniversities(String country) async {
    final response = await http.get(
        Uri.parse('http://universities.hipolabs.com/search?country=$country'));

    if (response.statusCode == 200) {
      List universities =
          jsonDecode(response.body); // Data universitas dari API
      emit(UniversityState(
          universities, country)); // Emit state dengan data universitas
    } else {
      throw Exception('Failed to load universities');
    }
  }
}

// Widget untuk menampilkan combobox negara ASEAN
class CountryDropdown extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CountryChanged, String>(
      builder: (context, selectedCountry) {
        return DropdownButton<String>(
          value: selectedCountry,
          onChanged: (String? newValue) {
            if (newValue != null) {
              context.read<CountryChanged>().changeCountry(newValue);
              context.read<UniversityCubit>().fetchUniversities(newValue);
            }
          },
          items: <String>[
            'Indonesia',
            'Malaysia',
            'Singapura',
            'Thailand',
            'Vietnam'
          ].map<DropdownMenuItem<String>>((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
        );
      },
    );
  }
}

// Widget untuk menampilkan list universitas
class UniversityList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<UniversityCubit, UniversityState>(
      builder: (context, state) {
        return Scaffold(
          appBar: AppBar(
            title: Text('Daftar Universitas',
                style: TextStyle(color: Colors.white)),
            backgroundColor: Colors.blue, // Warna biru untuk app bar
            actions: [
              CountryDropdown(), // Tambahkan combobox negara ASEAN di app bar
            ],
          ),
          body: Container(
            decoration: BoxDecoration(
              color: Colors.blue.shade50, // Warna latar belakang biru muda
            ),
            child: ListView.builder(
              itemCount: state.universities.length,
              itemBuilder: (BuildContext context, int index) {
                return Card(
                  elevation: 3,
                  margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  color: Colors.blue.shade100, // Warna biru muda untuk card
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: InkWell(
                    onTap: () {
                      String url = state.universities[index]['web_pages'][0];
                      // Buka URL situs web universitas
                    },
                    child: ListTile(
                      title: Text(
                        state.universities[index]['name'],
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors
                              .blue.shade900, // Warna biru tua untuk teks judul
                        ),
                      ),
                      subtitle: Text(
                        state.universities[index]['web_pages'][0],
                        style: TextStyle(
                          color: Colors.blue
                              .shade700, // Warna biru sedang untuk teks subjudul
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}

void main() {
  runApp(
    MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => CountryChanged()),
        BlocProvider(create: (context) => UniversityCubit()),
      ],
      child: MaterialApp(
        home: UniversityList(),
      ),
    ),
  );
}
