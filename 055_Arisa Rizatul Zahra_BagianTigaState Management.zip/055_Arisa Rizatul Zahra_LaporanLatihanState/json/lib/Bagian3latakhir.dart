import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:provider/provider.dart';

// Class untuk mengelola data universitas dan negara ASEAN
class UniversityProvider extends ChangeNotifier {
  List universities = []; // List untuk menyimpan data universitas
  String selectedCountry = 'Indonesia'; // Negara ASEAN yang dipilih

  // Fungsi untuk mengambil data universitas dari API berdasarkan negara
  Future<void> fetchUniversities(String country) async {
    final response = await http.get(
        Uri.parse('http://universities.hipolabs.com/search?country=$country'));

    if (response.statusCode == 200) {
      // Memeriksa status code response
      universities = jsonDecode(response.body); // Mengupdate data universitas
      notifyListeners(); // Memberitahu provider bahwa data telah diperbarui
    } else {
      throw Exception('Failed to load universities');
    }
  }

  // Fungsi untuk mengubah negara ASEAN yang dipilih
  void changeCountry(String country) {
    selectedCountry = country;
    fetchUniversities(country); // Memuat kembali data universitas
  }
}

// Widget untuk menampilkan combobox negara ASEAN
class CountryDropdown extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var universityProvider = Provider.of<UniversityProvider>(context);
    return DropdownButton<String>(
      value: universityProvider.selectedCountry,
      onChanged: (String? newValue) {
        if (newValue != null) {
          universityProvider.changeCountry(newValue);
        }
      },
      items: <String>[
        'Indonesia',
        'Malaysia',
        'Singapura',
        'Thailand',
        'Vietnam'
      ].map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    );
  }
}

// Widget untuk menampilkan list universitas
class UniversityList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var universityProvider = Provider.of<UniversityProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title:
            Text('Daftar Universitas', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.blue, // Warna biru untuk app bar
        actions: [
          CountryDropdown(), // Tambahkan combobox negara ASEAN di app bar
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          color: Colors.blue.shade50, // Warna latar belakang biru muda
        ),
        child: ListView.builder(
          itemCount: universityProvider.universities.length,
          itemBuilder: (BuildContext context, int index) {
            return Card(
              elevation: 3,
              margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              color: Colors.blue.shade100, // Warna biru muda untuk card
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: InkWell(
                onTap: () {
                  String url =
                      universityProvider.universities[index]['web_pages'][0];
                  // Buka URL situs web universitas
                },
                child: ListTile(
                  title: Text(
                    universityProvider.universities[index]['name'],
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors
                          .blue.shade900, // Warna biru tua untuk teks judul
                    ),
                  ),
                  subtitle: Text(
                    universityProvider.universities[index]['web_pages'][0],
                    style: TextStyle(
                      color: Colors.blue
                          .shade700, // Warna biru sedang untuk teks subjudul
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => UniversityProvider(),
      child: MaterialApp(
        home: UniversityList(),
      ),
    ),
  );
}
